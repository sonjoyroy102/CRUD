<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-btwen">
                <h4 style="float: left;">Student Information</h4>
                 <a href="create.php" class="btn btn-primary">Add Student</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include('connection.php');
                            $fetch = mysqli_query($con, "select * from crudoperation");
                            $row = mysqli_num_rows($fetch);
                            if($row > 0) {
                    
                                while ($r = mysqli_fetch_array($fetch)) {
                                ?>             
                            <tr>
                                <td><?php echo $r['ID']?></td>
                                <td><?php echo $r['name']?></td>
                                <td><?php echo $r['phone']?></td>
                                <td><?php echo $r['email']?></td>
                                <td><?php echo $r['address']?></td>
                                <td><button class="btn btn-sm btn-info m-2">View</button><button class="btn btn-sm btn-success m-2">Update</button><button class="btn btn-sm btn-danger m-2">Delete</button></td>
                            </tr>
                            <?php
                                }
                            } 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>