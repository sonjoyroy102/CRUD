<?php

include('connection.php');


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $query = mysqli_query($con, "insert into crudoperation (name, phone, email, address) value ('$name', '$phone', '$email', '$address')");
    if ($query) {
        echo "<script> alert('Data hasbeen added succesfully')</script>";
    } else{
        echo "<script> alert('there was an error')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css">
</head>
<body>
<div class=" bg-success d-flex justify-content-center align-items-center w-100 vh-100">
<div class="bg-dark w-25 rounded p-3">
    <h2 class="text-white text-center mb-3">Fill Form</h2>
<form method="POST">
<div class="mb-5">
    <input type="text" name="name" class="form-control p-2" placeholder="Enter Your Name">
</div>
<div class="mb-5">
    <input type="text" name="phone" class="form-control p-2" placeholder="Enter Your phone number">
</div>
<div class="mb-5">
    <input type="text" name="email" class="form-control p-2" placeholder="Enter Your email">
</div>
<div class="mb-5">
    <input type="text" name="address" class="form-control p-2" placeholder="Enter Your address">
</div>
<button class="btn btn-outline-success btn-md" type="submit">Create</button>
<button class="btn btn-outline-success btn-md" type=""><a href="view.php" class="text-white">Go Back Student Table</a></button>
</form>
</div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>