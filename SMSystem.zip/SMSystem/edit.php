<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mydb';

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Initialize variables
$id = $firstname = $lastname = $email = "";

// Fetch data to edit
if (isset($_GET['id'])) {
    $getid = intval($_GET['id']); // Prevent SQL injection
    $sql = "SELECT * FROM student WHERE id = $getid";
    $query = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($query);

    if ($data) {
        $id = $data['id'];
        $firstname = $data['firstname'];
        $lastname = $data['lastname'];
        $email = $data['email'];
    }
}

// Update student info
if (isset($_POST['edit'])) {
    $id = intval($_POST['id']);
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $sql = "UPDATE student SET firstname='$firstname', lastname='$lastname', email='$email' WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        header('Location: view.php');
        exit;
    } else {
        echo "Data Not Updated";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-sm-6">
            <h3>Edit Student Information</h3>
            <form action="" method="POST">
                <div class="mb-3">
                    <label class="form-label">First Name:</label>
                    <input type="text" name="firstname" class="form-control" value="<?php echo htmlspecialchars($firstname); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Last Name:</label>
                    <input type="text" name="lastname" class="form-control" value="<?php echo htmlspecialchars($lastname); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email:</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>">
                </div>
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <input class="btn btn-success" type="submit" value="Edit" name="edit">
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
