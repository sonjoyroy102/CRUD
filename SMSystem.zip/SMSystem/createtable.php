<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mydb';

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn){

die (mysqli_connect_error());

}

$sql = "CREATE TABLE student(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50))";


if ($conn->query($sql) === TRUE){
    echo 'Create Table Successfull.';
}else{
    echo mysqli_error($conn);
}

mysqli_close($conn);
?>