<?php
$servername = 'localhost';
$username = 'root';
$password = '';

$conn = mysqli_connect($servername,$username,$password);

if(!$conn){

die (mysqli_connect_error());

}

$sql = "CREATE DATABASE phpmydb";


if(mysqli_query($conn,$sql)){
    echo 'DB Create Successfull.';
}else{
    echo mysqli_error($conn);
}
mysqli_close($conn);
?>