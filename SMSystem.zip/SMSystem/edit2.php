<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mydb';

$conn = mysqli_connect($servername,$username,$password,$dbname);

if($_GET['id']){
$getid =  $_GET['id'];

$sql = "SELECT * FROM student WHERE id=$getid";
$query = mysqli_query($conn,$sql);
$data = mysqli_fetch_assoc($query);

$id         = $data['id'];
$firstname  = $data['firstname'];
$lastname   = $data['lastname'];
$email      = $data['email'];

}

if(isset($_POST['edit'])){
$id = $_POST['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];


$sql = "UPDATE student SET firstname='$firstname', lastname='$lastname', email='$email' WHERE id='$id'";
if(mysqli_query($conn,$sql) == TRUE) {
header('location:view.php');
    echo $sql1."Data Updated!";
} else{
echo"Data Not Updated";
}


}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMSystem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
                    <div class="col-sm-2">
                    </div>
                    <div class="col-sm-8">
                        <h3>Registration Form</h3>
                        <form class="" action="insert.php" method="POST">
                        First Name : <br>
                        <input type="text" name="firstname" value="<?php echo $firstname ?>"> <br>
                        Last Name :<br>
                        <input type="text" name="lastname" value="<?php echo $lastname ?>"><br>
                        Email :<br>
                        <input type="text" name="email" value="<?php echo $email ?>"><br><br>
                        <input type="text" name="id" value="<?php echo $id ?>">
                        <input class="btn btn-success" type="submit" value="Edit" name="submit">
                        </form>
                    </div>
                    <div class="col-sm-2">
                    </div>
                </div>
            </div>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        </body>
</html>
        
