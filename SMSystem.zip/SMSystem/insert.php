<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mydb';

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(isset($_POST['submit'])){
   $firstname = $_POST['firstname'];
   $lastname  =  $_POST['lastname'];
   $email     = $_POST['email'];

   $sql = "INSERT INTO student (firstname, lastname, email)
VALUES ('$firstname', ' $lastname', '$email')";

if(mysqli_query($conn,$sql) == TRUE){
    echo "Data Inserted.";
    header('location:insert.php');
}else{
    echo "Not Inserted";
}

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMSystem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-4">
        <div class="row justify-content-center">
                    <div class="col-sm-3">
                    </div>
                    <div class="col-sm-6">
                        <h3>Registration Form</h3>
                        <form class="" action="insert.php" method="post">
                        First Name : <br>
                        <input type="text" name="firstname"> <br>
                        Last Name :<br>
                        <input type="text" name="lastname"><br>
                        Email :<br>
                        <input type="text" name="email"><br><br>
                        <input class="btn btn-success" type="submit" value="Data Save" name="submit">
                        </form>
                    </div>
                    <div class="col-sm-3">
                    </div>
                </div>
            </div>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        </body>
</html>
        
